package org.techtown.cafereservation_se;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private View drawerView;
    Button btnReservation, btnCheck, btnCancel, btnCafe, btnLogin, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout=(DrawerLayout)findViewById(R.id.layout_main);
        drawerView=(View)findViewById(R.id.drawerView);

        drawerLayout.openDrawer(drawerView);


        //예약하기 버튼
        btnReservation=findViewById(R.id.btnReservation);
        btnReservation.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, Reservation.class);
                startActivity(intent);

                overridePendingTransition(R.anim.slide_left2, R.anim.slide_left);

            }
        });

        //예약확인 버튼
        btnCheck=findViewById(R.id.btnCheck);
        btnCheck.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, Check.class);
                startActivity(intent);

                overridePendingTransition(R.anim.slide_left2, R.anim.slide_left);

            }
        });

        //예약삭제 버튼
        btnCancel=findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, Cancel.class);
                startActivity(intent);

                overridePendingTransition(R.anim.slide_left2, R.anim.slide_left);

            }
        });

        //카페정보 버튼
        btnCafe=findViewById(R.id.btnCafe);
        btnCafe.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(MainActivity.this, Cafeinfo.class);
                startActivity(intent);

                overridePendingTransition(R.anim.slide_left2, R.anim.slide_left);

            }
        });

    }
}
